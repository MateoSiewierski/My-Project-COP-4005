﻿Imports System
Imports System.Reflection
Imports System.Runtime.InteropServices

' General Information about an assembly is controlled through the following
' set of attributes. Change these attribute values to modify the information
' associated with an assembly.

' Review the values of the assembly attributes

<Assembly: AssemblyTitle("GroupProject")>
<Assembly: AssemblyDescription("")>
<Assembly: AssemblyCompany("FIU KFSCIS")>
<Assembly: AssemblyProduct("GroupProject")>
<Assembly: AssemblyCopyright("Copyright © FIU KFSCIS 2026")>
<Assembly: AssemblyTrademark("")>

<Assembly: ComVisible(False)>

'The following GUID is for the ID of the typelib if this project is exposed to COM
<Assembly: Guid("005b663c-08d9-48ac-92d6-aeee55258e3f")>

' Version information for an assembly consists of the following four values:
'
'      Major Version
'      Minor Version
'      Build Number
'      Revision
'

<Assembly: AssemblyVersion("1.0.0.0")>
<Assembly: AssemblyFileVersion("1.0.0.0")>
