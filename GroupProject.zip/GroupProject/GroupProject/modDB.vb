﻿Imports System.Data.SqlClient
Module modDB
    'Connection string

    Public Const gstrConn As String = "" 'copy connection string from database
    'database objects
    Public objSQLConn As SqlConnection 'connections object
    Public objSQLCommand As SqlCommand 'command object
    Public objSQLDR As SqlDataReader 'data reader object
End Module
