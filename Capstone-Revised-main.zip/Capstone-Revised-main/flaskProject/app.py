from flask import Flask, render_template, request, session, jsonify
from markupsafe import Markup
import os
import re
import json
import uuid
import PyPDF2
import anthropic
from dotenv import load_dotenv

load_dotenv()

app = Flask(__name__)
app.secret_key = os.urandom(24)

UPLOAD_FOLDER = "uploads"
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

SAMPLE_JOBS = {
    "software_engineer": {
        "label": "Software Engineer",
        "desc": """We are looking for a skilled Software Engineer to join our team.

Requirements:
- Bachelor's degree in Computer Science or related field
- 2+ years of experience in software development
- Proficiency in Python, JavaScript, or Java
- Experience with REST APIs and web frameworks (Flask, Django, React, Node.js)
- Familiarity with Git, databases (SQL/NoSQL), and cloud platforms (AWS, GCP, or Azure)
- Strong understanding of data structures, algorithms, and software design patterns
- Experience with Agile/Scrum development methodologies

Preferred:
- Experience with Docker and containerization
- Knowledge of CI/CD pipelines
- Contributions to open-source projects"""
    },
    "data_analyst": {
        "label": "Data Analyst",
        "desc": """We are seeking a Data Analyst to help drive data-informed decisions.

Requirements:
- Bachelor's degree in Statistics, Mathematics, Computer Science, or related field
- 1-3 years of experience in data analysis
- Strong proficiency in SQL and Excel
- Experience with Python or R for data manipulation and visualization
- Familiarity with BI tools (Tableau, Power BI, or Looker)
- Ability to communicate insights clearly to non-technical stakeholders
- Experience with data cleaning, ETL processes, and statistical analysis

Preferred:
- Knowledge of machine learning fundamentals
- Experience with big data tools (Spark, Hadoop)
- Background in A/B testing and experimental design"""
    },
    "it_administrator": {
        "label": "IT Administrator",
        "desc": """We are hiring an IT Administrator to manage and maintain our IT infrastructure.

Requirements:
- Bachelor's degree in Information Technology, Computer Science, or related field
- 2+ years of experience in IT administration or systems administration
- Experience with Windows Server, Active Directory, and Group Policy
- Knowledge of networking fundamentals (TCP/IP, DNS, DHCP, VPN, firewalls)
- Familiarity with cloud platforms (Microsoft Azure or AWS)
- Experience with backup solutions and disaster recovery planning
- Knowledge of cybersecurity best practices

Preferred:
- CompTIA A+, Network+, Security+, or Microsoft certifications
- Experience with virtualization (VMware, Hyper-V)
- Scripting knowledge (PowerShell, Bash)"""
    }
}


def extract_text(file_path):
    text = ""
    with open(file_path, "rb") as file:
        reader = PyPDF2.PdfReader(file)
        for page in reader.pages:
            page_text = page.extract_text()
            if page_text:
                text += page_text + " "
    return text


def screen_resume(resume_text, job_desc, candidate_name="Candidate"):
    api_key = os.getenv("ANTHROPIC_API_KEY")
    if not api_key:
        raise ValueError("ANTHROPIC_API_KEY not found. Please add it to your .env file.")

    client = anthropic.Anthropic(api_key=api_key)

    prompt = f"""You are a senior HR recruiter and technical hiring manager. Evaluate this candidate's resume against the job description provided.

Your evaluation must be based on actual fit for this specific role. Consider experience level, relevant skills, career trajectory, and how their background aligns with what the job requires.

---
CANDIDATE: {candidate_name}

RESUME:
{resume_text[:6000]}

---
JOB DESCRIPTION:
{job_desc[:3000]}

---

Respond ONLY with a valid JSON object in exactly this format with no extra text or markdown:

{{
  "score": <integer 0-100>,
  "score_label": "<Poor Match | Weak Match | Moderate Match | Strong Match | Excellent Match>",
  "score_reasoning": "<2-3 sentences explaining the score based on actual job requirements>",
  "matched_skills": ["<skill from the job the candidate clearly has>"],
  "missing_skills": ["<required skill the candidate lacks>"],
  "strengths": ["<specific strength relevant to this role>"],
  "gaps": ["<specific gap relevant to this role>"],
  "recommendations": ["<actionable suggestion for the candidate>"],
  "hiring_recommendation": "<Strong Recommend | Recommend | Borderline | Do Not Recommend>",
  "hiring_justification": "<one sentence justifying the recommendation>"
}}
"""

    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1500,
        messages=[{"role": "user", "content": prompt}]
    )

    raw = message.content[0].text.strip()
    raw = re.sub(r'^```(?:json)?\s*', '', raw)
    raw = re.sub(r'\s*```$', '', raw)
    return json.loads(raw)


@app.route("/", methods=["GET", "POST"])
def index():
    results = []
    error = None
    job_desc = ""
    session_history = session.get("history", [])

    if request.method == "POST":
        files = request.files.getlist("resumes")
        job_desc = request.form.get("job_desc", "").strip()
        sample_job = request.form.get("sample_job", "")

        if sample_job and sample_job in SAMPLE_JOBS:
            job_desc = SAMPLE_JOBS[sample_job]["desc"]

        if not files or all(f.filename == "" for f in files):
            error = "Please upload at least one resume PDF."
        elif not job_desc:
            error = "Please provide a job description."
        else:
            if not os.path.exists(UPLOAD_FOLDER):
                os.makedirs(UPLOAD_FOLDER)

            for file in files:
                if file.filename == "":
                    continue
                if not file.filename.lower().endswith(".pdf"):
                    results.append({"name": file.filename, "error": "Only PDF files are supported."})
                    continue

                file_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
                file.save(file_path)
                candidate_name = os.path.splitext(file.filename)[0]

                try:
                    resume_text = extract_text(file_path)
                    if resume_text.strip() == "":
                        results.append({"name": candidate_name, "error": "Could not extract text from this PDF."})
                        continue

                    analysis = screen_resume(resume_text, job_desc, candidate_name)
                    analysis["name"] = candidate_name
                    analysis["filename"] = file.filename
                    results.append(analysis)

                except ValueError as ve:
                    error = str(ve)
                    break
                except json.JSONDecodeError:
                    results.append({"name": candidate_name, "error": "Unexpected response format. Please try again."})
                except Exception as e:
                    results.append({"name": candidate_name, "error": str(e)})

            successful = [r for r in results if "score" in r]
            failed = [r for r in results if "score" not in r]
            successful.sort(key=lambda x: x["score"], reverse=True)
            results = successful + failed

            if successful:
                history_entry = {
                    "id": str(uuid.uuid4())[:8],
                    "job_snippet": job_desc[:60] + "..." if len(job_desc) > 60 else job_desc,
                    "candidates": [
                        {"name": r["name"], "score": r["score"], "rec": r["hiring_recommendation"]}
                        for r in successful
                    ]
                }
                session_history.insert(0, history_entry)
                session_history = session_history[:5]
                session["history"] = session_history

    return render_template(
        "index.html",
        results=results,
        error=error,
        job_desc=job_desc,
        sample_jobs=SAMPLE_JOBS,
        session_history=session_history
    )

if __name__ == "__main__":
    app.run(debug=True)
